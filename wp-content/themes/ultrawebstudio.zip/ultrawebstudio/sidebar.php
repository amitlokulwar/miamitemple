<div id="sidebar">
	<?php if ( !function_exists('generated_dynamic_sidebar')
			|| !generated_dynamic_sidebar() ) : ?>	 
	<?php endif; ?>
</div>	
	

	




