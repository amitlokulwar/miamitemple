<div class="post-share">
	<p class="trigger"><a href="#toggle">share</a></p>

	<div class="toggle_container">														
		<ul>
			<li><a href="http://twitter.com/home?status=<?php the_title(); echo(' '); the_permalink(); ?>" rel="nofollow" class="tipRight" title="Twitter" target="_blank">
					<img src="<?php echo get_template_directory_uri(); ?>/images/icons/share-twitter.png" alt="" />
				</a>
			</li>
			<li><a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" class="tipRight" title="Facebook"  target="_blank" >
				<img src="<?php echo get_template_directory_uri(); ?>/images/icons/share-facebook.png" alt="" />
				</a>
			</li>						
			<li><a href="http://www.stumbleupon.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>" class="tipRight" title="Stubleupon" target="_blank" >
					<img src="<?php echo get_template_directory_uri(); ?>/images/icons/share-stumbleupon.png" alt="" />
				</a>
			</li>
			<li><a href="http://www.blinklist.com/index.php?Action=Blink/addblink.php&amp;Url=<?php the_permalink(); ?>&amp;Title=<?php the_title(); ?>" class="tipRight" title="Blinklist" target="_blank" >
					<img src="<?php echo get_template_directory_uri(); ?>/images/icons/share-blinklist.png" alt="" />
				</a>
			</li>
			<li><a href="http://www.digg.com/submit?phase=2&amp;url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>" class="tipRight" title="Digg" target="_blank" >
					<img src="<?php echo get_template_directory_uri(); ?>/images/icons/share-digg.png" alt="" />
				</a>
			</li>
			<li><a href="http://reddit.com/submit?url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>" class="tipRight" title="Reddit" target="_blank" >
					<img src="<?php echo get_template_directory_uri(); ?>/images/icons/share-redit.png" alt="" />
				</a>
			</li>
			<li><a href="http://del.icio.us/post?url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>" class="tipRight" title="Delicious" target="_blank" >
					<img src="<?php echo get_template_directory_uri(); ?>/images/icons/share-delicious.png" alt="" />
				</a>
			</li>
			<li><a href="http://in.buzz.yahoo.com/buzz?targetUrl=<?php the_permalink(); ?>" class="tipRight" title="Buzz" target="_blank" >
					<img src="<?php echo get_template_directory_uri(); ?>/images/icons/share-buzz.png" alt="" />
				</a>
			</li>
		</ul>							
	</div>  <!-- .toggle_container -->

</div><!-- .post-share -->

	